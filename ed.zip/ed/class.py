class Elemento:
    def __init__(self, valor):
        self.valor = valor
        self.proximo = None


class ListaEncadeada:
    def __init__(self):
        self.cabeca = None

    def inserirNoFinal(self, valor):
        novo = Elemento(valor)
        if self.cabeca is None:
            self.cabeca = novo
            return
        atual = self.cabeca
        while atual.proximo is not None:
            atual = atual.proximo
        atual.proximo = novo

    def imprimirLista(self):
        if self.cabeca is None:
            print("Lista vazia")
            return
        atual = self.cabeca
        while atual is not None:
            print(atual.valor, end=" -> ")
            atual = atual.proximo
        print("null")

    def procurar(self, valor):
        atual = self.cabeca
        while atual is not None:
            if atual.valor == valor:
                return True
            atual = atual.proximo
        return False

minha_lista = ListaEncadeada()

minha_lista.inserirNoFinal(10)
minha_lista.inserirNoFinal(20)

'''

for v in [10, 20, 30, 40, 50]:
    minha_lista.inserirNoFinal(v)
'''
minha_lista.imprimirLista()